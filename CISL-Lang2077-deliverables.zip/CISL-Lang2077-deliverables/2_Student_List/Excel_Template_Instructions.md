# Excel Template Instructions

An Excel version of the student list should be created with columns:
- Student Name
- Student ID  
- Program/Year
- Team Assignment
- Contact Email
- Participation Status
- Final Grade (if applicable)

Save as: "LANG2077_Student_List_Complete.xlsx"
